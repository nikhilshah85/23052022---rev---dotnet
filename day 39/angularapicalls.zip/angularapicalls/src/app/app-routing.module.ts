import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommentsdataComponent } from './components/commentsdata/commentsdata.component';
import { HomeComponent } from './components/home/home.component';
import { PostdataComponent } from './components/postdata/postdata.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'comments',component:CommentsdataComponent},
  {path:'post',component:PostdataComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
