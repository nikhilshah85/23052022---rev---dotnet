import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentsdataComponent } from './commentsdata.component';

describe('CommentsdataComponent', () => {
  let component: CommentsdataComponent;
  let fixture: ComponentFixture<CommentsdataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommentsdataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CommentsdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
