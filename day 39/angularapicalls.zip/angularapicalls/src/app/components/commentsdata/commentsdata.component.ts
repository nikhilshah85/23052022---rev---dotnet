import { Component, OnInit } from '@angular/core';
import { ExternaldataService } from 'src/app/services/externaldata.service';

@Component({
  selector: 'app-commentsdata',
  templateUrl: './commentsdata.component.html',
  styleUrls: ['./commentsdata.component.css']
})
export class CommentsdataComponent implements OnInit {


  _externalData:ExternaldataService;

  constructor(externaDataRef:ExternaldataService){
    this._externalData = externaDataRef;
   }

  ngOnInit(): void {
  }

}
