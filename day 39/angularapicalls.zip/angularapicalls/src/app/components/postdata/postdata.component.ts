import { Component, OnInit } from '@angular/core';
import { ExternaldataService } from 'src/app/services/externaldata.service';

@Component({
  selector: 'app-postdata',
  templateUrl: './postdata.component.html',
  styleUrls: ['./postdata.component.css']
})
export class PostdataComponent implements OnInit {


  _externalData:ExternaldataService;

  constructor(externaDataRef:ExternaldataService){
    this._externalData = externaDataRef;
   }

  ngOnInit(): void {
  }

}
