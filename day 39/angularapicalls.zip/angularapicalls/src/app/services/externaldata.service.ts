import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ExternaldataService {



  _http:HttpClient;

  commentsData:any;
  postData:any;
  userData:any;
  toDosData:any;

  constructor(httpClientRef:HttpClient)
  {
    this._http = httpClientRef;
   }

   getCommentsDataFromJsonPlaceHolder()
   {   
      this._http.get('https://jsonplaceholder.typicode.com/comments').subscribe( data => {
        this.commentsData = data;      

      })
   }

   getPostDataFromJsonPlaceHolder()
   {   
      this._http.get('https://jsonplaceholder.typicode.com/posts').subscribe( data => {
        this.postData = data;      

      })
   }

   getUserDataFromJsonPlaceHolder()
   {   
      this._http.get('https://jsonplaceholder.typicode.com/users').subscribe( data => {
        this.userData = data;      

      })
   }
   gettoDosDataFromJsonPlaceHolder()
   {   
      this._http.get('https://jsonplaceholder.typicode.com/todos').subscribe( data => {
        this.toDosData = data;      

      })
   }



}
