import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AllemployeesComponent } from './components/employee/allemployees/allemployees.component';
import { DeleteemployeeComponent } from './components/employee/deleteemployee/deleteemployee.component';
import { EditemployeeComponent } from './components/employee/editemployee/editemployee.component';
import { PostemplyeeComponent } from './components/employee/postemplyee/postemplyee.component';

const routes: Routes = [
  {path:'',component:AllemployeesComponent},
  {path:'allemp',component:AllemployeesComponent},
  {path:'addemp',component:PostemplyeeComponent},
  {path:'edit',component:EditemployeeComponent},
  {path:'delete',component:DeleteemployeeComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
