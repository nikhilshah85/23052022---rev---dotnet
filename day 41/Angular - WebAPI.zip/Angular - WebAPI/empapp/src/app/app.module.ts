import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AllemployeesComponent } from './components/employee/allemployees/allemployees.component';
import { PostemplyeeComponent } from './components/employee/postemplyee/postemplyee.component';
import { DeleteemployeeComponent } from './components/employee/deleteemployee/deleteemployee.component';
import { EditemployeeComponent } from './components/employee/editemployee/editemployee.component';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms'
@NgModule({
  declarations: [
    AppComponent,    
    AllemployeesComponent,
    PostemplyeeComponent,
    DeleteemployeeComponent,
    EditemployeeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, HttpClientModule, FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
