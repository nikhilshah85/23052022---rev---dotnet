import { Component, OnInit } from '@angular/core';
import { EmpService } from 'src/app/services/emp.service';

@Component({
  selector: 'app-allemployees',
  templateUrl: './allemployees.component.html',
  styleUrls: ['./allemployees.component.css']
})
export class AllemployeesComponent implements OnInit {

  _empService:EmpService;
  constructor(empServiceRef:EmpService) {
    this._empService = empServiceRef;
   }

  ngOnInit(): void {
  }

}
