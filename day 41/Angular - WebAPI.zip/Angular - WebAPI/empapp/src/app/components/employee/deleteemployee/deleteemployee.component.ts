import { Component, OnInit } from '@angular/core';
import { EmpService } from 'src/app/services/emp.service';

@Component({
  selector: 'app-deleteemployee',
  templateUrl: './deleteemployee.component.html',
  styleUrls: ['./deleteemployee.component.css']
})
export class DeleteemployeeComponent implements OnInit {

  _empService:EmpService;
  constructor(empServiceRef:EmpService) {
    this._empService = empServiceRef;
   }

  ngOnInit(): void {
  }

}
