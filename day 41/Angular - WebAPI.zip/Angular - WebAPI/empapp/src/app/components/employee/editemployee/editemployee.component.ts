import { Component, OnInit } from '@angular/core';
import { EmpService } from 'src/app/services/emp.service';

@Component({
  selector: 'app-editemployee',
  templateUrl: './editemployee.component.html',
  styleUrls: ['./editemployee.component.css']
})
export class EditemployeeComponent implements OnInit {
  _empService:EmpService;
  constructor(empServiceRef:EmpService) {
    this._empService = empServiceRef;
   }

  ngOnInit(): void {
  }

}
