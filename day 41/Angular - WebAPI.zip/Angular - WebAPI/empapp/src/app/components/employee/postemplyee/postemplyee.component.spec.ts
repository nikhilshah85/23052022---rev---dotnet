import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostemplyeeComponent } from './postemplyee.component';

describe('PostemplyeeComponent', () => {
  let component: PostemplyeeComponent;
  let fixture: ComponentFixture<PostemplyeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PostemplyeeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PostemplyeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
