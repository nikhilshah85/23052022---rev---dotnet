import { Component, OnInit } from '@angular/core';
import { EmpService } from 'src/app/services/emp.service';
@Component({
  selector: 'app-postemplyee',
  templateUrl: './postemplyee.component.html',
  styleUrls: ['./postemplyee.component.css']
})
export class PostemplyeeComponent implements OnInit {

  _empService:EmpService;
  constructor(empServiceRef:EmpService) {
    this._empService = empServiceRef;
   }

   

  ngOnInit(): void {
  }

}
