import { HttpClient } from '@angular/common/http';
import { ConstantPool } from '@angular/compiler';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  _http:HttpClient;
  allemployee:any;

  constructor(httpClientRef:HttpClient) {
    this._http = httpClientRef;
   }

   getEmployee()
   {
      this._http.get('https://localhost:7211/api/employee').subscribe( data=>{
        this.allemployee = data;
      } )
   }


   postEmployee(newEmpObj:any)
   {

    console.log(newEmpObj);
    var newEmp = {
      "empNo": newEmpObj.empNo,
      "empName": newEmpObj.empName,
      "empDesigantion": newEmpObj.empDesignation,
      "empSalary": newEmpObj.empSalary,
      "empDept": newEmpObj.empDept
    };
    console.log('Makeing a call');
    this._http.post('https://localhost:7211/api/employee',newEmp).subscribe(result =>{
      console.log('Started');
      console.log(result);
      console.log('ended');
    })
   }


  

   EditEmployee(){

    var changes = {
      "empNo": 5,
      "empName": "Akshay Kumar",
      "empDesigantion": "Cloud Developer",
      "empSalary": 25000,
      "empDept": 30  
    }
    
    
    this._http.put('https://localhost:7211/api/employee/5',changes).subscribe( result =>{
      console.log(result);
    })
   


   }


   deleteEmployee(){

      this._http.delete('https://localhost:7211/api/employee/22').subscribe(result =>{
        console.log(result);
      })


   }


}
