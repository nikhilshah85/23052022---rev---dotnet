﻿using System;
using System.Collections.Generic;

namespace employeeWEbAPI.Models.EF
{
    public partial class Comment
    {
        public int CommentId { get; set; }
        public int? UserId { get; set; }
        public string? Comment1 { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? PostId { get; set; }
        public string? CommentImage { get; set; }

        public virtual Post? Post { get; set; }
        public virtual User? User { get; set; }
    }
}
