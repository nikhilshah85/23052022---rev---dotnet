﻿using System;
using System.Collections.Generic;

namespace employeeWEbAPI.Models.EF
{
    public partial class DeptInfo
    {
        public DeptInfo()
        {
            EmployeeInfos = new HashSet<EmployeeInfo>();
        }

        public int DeptNo { get; set; }
        public string? DeptName { get; set; }
        public string? DeptLocaton { get; set; }

        public virtual ICollection<EmployeeInfo> EmployeeInfos { get; set; }
    }
}
