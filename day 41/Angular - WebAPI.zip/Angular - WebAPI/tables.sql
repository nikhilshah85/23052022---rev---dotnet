create database employeeDB

use employeeDB

create table deptInfo
(
	deptNo int primary key,
	deptName varchar(20),
	deptLocaton varchar(20)
)
insert into deptInfo values (10,'Accounts','Mumbai')
insert into deptInfo values (20,'HR','New Yark')
insert into deptInfo values (30,'IT','London')
insert into deptInfo values (40,'Sales','Paris')
insert into deptInfo values (50,'Advt.','Pune')

create table employeeInfo
(
	empNo int primary key,
	empName varchar(20),
	empDesigantion varchar(20),
	empSalary int,
	empDept int,

	constraint fk_empDept foreign key(empDept) references deptInfo
	)

insert into employeeInfo values(1,'Nikhil','Consultant',3000,30)
insert into employeeInfo values(2,'Priya','Accounts Manager',3000,10)
insert into employeeInfo values(3,'Riya','Sr.Developer',3000,30)
insert into employeeInfo values(4,'Jiya','UI Developer',3000,30)
insert into employeeInfo values(5,'Akshay','Sales Manager',3000,40)



select * from deptInfo
select * from employeeInfo